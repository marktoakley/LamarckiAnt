mkdir opt0
cp start opt0/start
for (( length=1; length <= $1; length++ )); do
  echo '#!/bin/bash' > opt.sh
  echo 'xa0=( `cat ./start` )' >>opt.sh
  echo 'xb=( `cat ./finish` )' >>opt.sh
  dirname=opt"$length"_
  for (( num=1; num <= $length; num++ )); do
    let "num1= $1 - $length + $num" 
    if [ $num == 1 ]; then
      echo "for (( a$num = 1; a$num <= $num1; a$num++ )); do" >>opt.sh
    else
      let "num2= $num - 1"
      echo "for (( a$num = a$num2 + 1; a$num <= $num1; a$num++ )); do" >>opt.sh
    fi
    echo name$num='$'a$num.list >>opt.sh
    dirname="$dirname"'$a'$num
  done
  echo 'xa=( `echo ${xa0[@]}` )' >>opt.sh
  for (( num=1; num <= $length; num++ )); do
    echo for i in '`'cat ./'$'name$num'`;' 'do for j in {1..3}; do let "k= $i*3 - $j"; xa[$k]=${xb[$k]}; done;done' >>opt.sh
  done
  echo name=$dirname >>opt.sh
  echo 'if [ ! -d $name ];then' >>opt.sh
  echo 'mkdir $name' >>opt.sh
  echo 'echo $name >>name.list' >>opt.sh
  xa=( `cat ./start` ) 
  let "lx= ${#xa[@]} -3"
  echo 'for i in {0..'$lx'..3};do echo ${xa[@]:$i:3} >>$name/start;done' >>opt.sh
  echo 'fi' >>opt.sh
  for (( num=1; num <= $length; num++ )); do
    echo "done" >>opt.sh
  done
  chmod +x opt.sh
  ./opt.sh
  mv opt.sh opt$length.sh
done
