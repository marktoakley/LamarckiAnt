#!/bin/bash
xa0=( `cat ./start` )
xb=( `cat ./finish` )
for (( a1 = 1; a1 <= 4; a1++ )); do
name1=$a1.list
xa=( `echo ${xa0[@]}` )
for i in `cat ./$name1`; do for j in {1..3}; do let "k= $i*3 - $j"; xa[$k]=${xb[$k]}; done;done
name=opt1_$a1
if [ ! -d $name ];then
mkdir $name
echo $name >>name.list
for i in {0..27..3};do echo ${xa[@]:$i:3} >>$name/start;done
fi
done
