#!/bin/bash
xa0=( `cat ./start` )
xb=( `cat ./finish` )
for (( a1 = 1; a1 <= 2; a1++ )); do
name1=$a1.list
for (( a2 = a1 + 1; a2 <= 3; a2++ )); do
name2=$a2.list
for (( a3 = a2 + 1; a3 <= 4; a3++ )); do
name3=$a3.list
xa=( `echo ${xa0[@]}` )
for i in `cat ./$name1`; do for j in {1..3}; do let "k= $i*3 - $j"; xa[$k]=${xb[$k]}; done;done
for i in `cat ./$name2`; do for j in {1..3}; do let "k= $i*3 - $j"; xa[$k]=${xb[$k]}; done;done
for i in `cat ./$name3`; do for j in {1..3}; do let "k= $i*3 - $j"; xa[$k]=${xb[$k]}; done;done
name=opt3_$a1$a2$a3
if [ ! -d $name ];then
mkdir $name
echo $name >>name.list
for i in {0..27..3};do echo ${xa[@]:$i:3} >>$name/start;done
fi
done
done
done
