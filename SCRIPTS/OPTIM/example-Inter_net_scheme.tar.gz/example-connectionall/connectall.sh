for name in `cat ./name.list`
do 
   level=${name:3:1}
   for (( j=0; j<$level; j++ ));do
     pos=j+5
     res[j]=${name:$pos:1}
   done
   if [ $level -eq "1" ]; then
      conn=con1_0_${res[0]}
      echo $conn
      mkdir $conn
      cp opt0/points.final $conn/start
      cp $name/points.final $conn/finish 
   elif [ $level -gt "1" ]; then
      let "uplevel= $level - 1"
      for (( j=0; j<$level; j++ ));do
         name1=opt"$uplevel"_
         for (( k=0; k<$level; k++ ));do
            if [ $k != $j ]; then
               name1=$name1${res[k]}
            fi
         done
         num1=${name:5}
         num2=${name1:5}
         conn=con"$level"_"$num2"_$num1
         mkdir $conn
         cp $name1/points.final $conn/start
         cp $name/points.final $conn/finish
         echo $conn
      done
   fi
done
